---
title: Sabbir AI Agent
emoji: 🤖
colorFrom: blue
colorTo: indigo
sdk: docker
pinned: false
---

# 🤖 Sabbir AI Agent

আমার নিজের বানানো AI Agent — বাংলা ও English দুই ভাষায় কথা বলে।

ক্ষমতা: web search, calculator, note, document পড়া (RAG), planning, Python code execution, long-term memory।
