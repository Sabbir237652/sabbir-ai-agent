# 🎨 Sabbir AI Agent — নিজের মতো সাজানোর গাইড (Customization)

আপনার agent-এর পুরো identity এখন **একটা জায়গা থেকে** বদলানো যায়:
`app.py` (বা `sabbir_ai_agent.py`) ফাইলের একদম উপরের দিকে **`BRAND = {...}`** অংশ।

মোবাইলে বদলাবেন কীভাবে: **Hugging Face → আপনার Space → Files → app.py → Edit (✏️) →
বদলান → Commit changes** — ব্যস, নিজে থেকেই নতুন রূপে চালু হয়ে যাবে!

---

## যা যা বদলাতে পারবেন

### ১. নাম ও Tagline
```python
"name": "Sabbir AI Agent",          # ← এখানে নতুন নাম
"tagline": "আপনার ব্যক্তিগত AI সহকারী",  # ← header-এর ছোট লেখা
```

### ২. Brand Color (৩টা রঙের gradient)
```python
"color1": "#6366f1",   # প্রথম রঙ
"color2": "#8b5cf6",   # মাঝের রঙ
"color3": "#ec4899",   # শেষ রঙ
```
- পছন্দের রঙের hex code নিন: https://htmlcolorcodes.com
- উদাহরণ — সবুজ theme: `#059669`, `#10b981`, `#34d399`
- উদাহরণ — কমলা-লাল: `#f59e0b`, `#f97316`, `#ef4444`
- বদলালেই logo-box, বাটন, user bubble, title — সব নিজে থেকে নতুন রঙ নেবে!

### ৩. Logo / Avatar বদলানো
- আপনার নতুন ছবির নাম দিন **`logo.png`** (বর্গাকার ছবি হলে ভালো, যেমন 512×512)
- Hugging Face → Files → Upload files → নতুন `logo.png` দিন (পুরনোটা replace হবে)
- Header-এর বড় logo আর প্রতিটি bot message-এর পাশের ছোট avatar — দুটোই বদলে যাবে

### ৪. Personality (চরিত্র)
```python
"personality": "তুমি বন্ধুসুলভ, বুদ্ধিমান...",
```
যেমন লিখতে পারেন: *"তুমি মজার, সবসময় রসিকতা করো"* বা *"তুমি গম্ভীর ও পেশাদার"*

### ৫. Voice / Tone (কথার ধরন)
```python
"tone": "উষ্ণ, ভদ্র আর প্রাণবন্ত...",
```
যেমন: *"খুব সংক্ষেপে কথা বলো"* বা *"কবিতার মতো সুন্দর ভাষায় কথা বলো"*

### ৬. AI Response Style (উত্তর সাজানোর নিয়ম)
```python
"response_style": "ছোট প্রশ্নের ছোট উত্তর...",
```
যেমন: *"সবসময় bullet point-এ উত্তর দাও"* বা *"প্রতিটা উত্তরের শেষে একটা টিপ দাও"*

### ৭. Welcome Message
```python
"welcome": "আসসালামু আলাইকুম! 👋 আমি...",
```
প্রথমবার খুললে এটাই দেখাবে। `\n` দিলে নতুন লাইন হয়।

### ৮. Loading লেখা
```python
"thinking_text": "Sabbir ভাবছে",   # যেমন: "একটু দাঁড়ান...", "চিন্তা করছি 🤔"
```

### ৯. Suggestion Chips (chat-এর উপরের বাটন)
```python
"chips": [
    "👋 তুমি কী কী করতে পারো?",
    "🌦️ আজকের আবহাওয়া কেমন?",
    # যত খুশি যোগ করুন, বাদ দিন
],
```

---

## ⚠️ বদলানোর সময় সাবধানতা

- প্রতিটা লেখা `"..."` — এই **quotation-এর ভেতরে** রাখবেন
- লাইনের শেষের **কমা (,)** মুছবেন না
- বাংলা/English/emoji — সব চলবে
- ভুল হয়ে গেলে ভয় নেই: Hugging Face-এ Files → app.py → History থেকে আগের version ফিরিয়ে আনা যায়

## 💡 এক নজরে: কী বদলালে কী হয়

| বদলাবেন | ফলাফল |
|---|---|
| `name` | Header title, browser tab, AI নিজের পরিচয় — সব জায়গায় নতুন নাম |
| `color1-3` | পুরো UI-র রঙ (বাটন, bubble, gradient, glow) |
| `logo.png` ফাইল | Header logo + bot avatar |
| `personality`/`tone`/`response_style` | AI-র কথা বলার ধরন সাথে সাথে বদলাবে |
| `welcome` | প্রথম খোলার message |
| `chips` | Suggestion বাটনগুলো |
