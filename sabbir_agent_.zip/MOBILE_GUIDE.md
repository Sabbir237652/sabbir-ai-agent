# 📱 মোবাইল দিয়ে Sabbir AI Agent লাইভ সার্ভারে Publish করার সম্পূর্ণ গাইড

**যা লাগবে:** শুধু আপনার মোবাইলের ব্রাউজার (Chrome) + একটা email। কোনো কম্পিউটার লাগবে না!
**খরচ:** ০ টাকা। কোনো কার্ডও লাগবে না।
**ফলাফল:** একটা স্থায়ী লিংক (যেমন: `https://sabbir-ai-agent.hf.space`) — যেকোনো ফোন/কম্পিউটার থেকে খোলা যাবে, ২৪/৭ চালু থাকবে।

---

## ধাপ ১: Hugging Face-এ ফ্রি account খুলুন (২ মিনিট)

1. মোবাইলের ব্রাউজারে যান: **https://huggingface.co/join**
2. Email আর password দিয়ে **Sign Up** করুন
3. Email-এ যে verification link আসবে সেটায় ক্লিক করুন

## ধাপ ২: নতুন Space বানান (২ মিনিট)

1. ব্রাউজারে যান: **https://huggingface.co/new-space**
2. ফর্মটা এভাবে পূরণ করুন:
   - **Space name:** `sabbir-ai-agent` (বা আপনার পছন্দমতো)
   - **License:** MIT (বা খালি রাখুন)
   - **Select the Space SDK:** ⚠️ **Docker** বেছে নিন (খুব গুরুত্বপূর্ণ!)
   - **Docker template:** Blank
   - **Space hardware:** CPU basic (ফ্রি)
   - **Public / Private:** **Public** রাখুন (ফ্রি account-এ public-ই ভালো চলে;
     চিন্তা নেই — আমাদের Access Code পাসওয়ার্ড আছে, অন্য কেউ ব্যবহার করতে পারবে না)
3. **Create Space** বাটনে চাপ দিন

## ধাপ ৩: ৪টা ফাইল upload করুন (৫ মিনিট)

Space তৈরি হলে আপনি Space-এর পেজে পৌঁছাবেন।

1. উপরের **"Files"** ট্যাবে চাপ দিন
2. ডানদিকে **"+ Contribute"** → **"Upload files"** চাপুন
3. এই ZIP থেকে ৫টা ফাইল upload করুন:
   - `app.py`
   - `Dockerfile`
   - `requirements.txt`
   - `README.md`
   - `logo.png` (আপনার agent-এর logo!)
   (মোবাইলে ZIP খুলতে না পারলে: ZIP-টা আগে মোবাইলের Files app-এ extract করুন)
4. নিচে **"Commit changes to main"** বাটনে চাপ দিন

## ধাপ ৪: গোপন Key গুলো সেট করুন (৩ মিনিট) — সবচেয়ে গুরুত্বপূর্ণ! 🔐

1. Space-এর পেজে **"Settings"** ট্যাবে যান (উপরে ডানদিকে ⚙️)
2. নিচে scroll করে **"Variables and secrets"** অংশে যান
3. **"New secret"** চেপে একে একে ২টা secret যোগ করুন:

   | Name (নাম) | Value (মান) |
   |---|---|
   | `GEMINI_API_KEY` | আপনার Gemini key (AQ.Ab8... দিয়ে শুরু) |
   | `ACCESS_CODE` | আপনার নিজের বানানো একটা পাসওয়ার্ড (যেমন: `sabbir2026`) |

   ⚠️ `ACCESS_CODE` টা মনে রাখুন — এটাই আপনার agent-এ ঢোকার পাসওয়ার্ড!

## ধাপ ৫: চালু হওয়ার অপেক্ষা (৩-৫ মিনিট)

1. **"App"** ট্যাবে ফিরে যান
2. "Building..." দেখাবে — ৩-৫ মিনিট অপেক্ষা করুন
3. Build শেষ হলে আপনার Sabbir AI Agent-এর chat UI দেখা যাবে! 🎉

## ধাপ ৬: ব্যবহার করুন — যেকোনো ডিভাইস থেকে! 🌍

আপনার স্থায়ী লিংক হবে:
```
https://huggingface.co/spaces/আপনার-username/sabbir-ai-agent
```
- এই লিংক যেকোনো মোবাইল/ট্যাব/কম্পিউটারের ব্রাউজারে খুলুন
- প্রথমবার **Access Code** (আপনার পাসওয়ার্ড) দিন
- ব্যস! Chat শুরু করুন — আপনার agent এখন সারা পৃথিবী থেকে accessible! 

💡 **টিপ:** মোবাইলের Chrome-এ লিংকটা খুলে menu → **"Add to Home screen"**
চাপলে এটা একটা app-এর মতো আপনার home screen-এ থাকবে! 📲

---

## ❓ সমস্যা হলে

| সমস্যা | সমাধান |
|---|---|
| Build fail হচ্ছে | Files ট্যাবে দেখুন ৪টা ফাইলই আছে কিনা, বিশেষ করে `Dockerfile` |
| "API key পাওয়া যায়নি" | Settings → Secrets-এ `GEMINI_API_KEY` ঠিকমতো বসেছে কিনা দেখুন |
| পাসওয়ার্ড কাজ করছে না | Settings → Secrets-এ `ACCESS_CODE`-এর বানান মিলিয়ে দেখুন |
| Space ঘুমিয়ে যায় | ফ্রি Space ৪৮ ঘণ্টা ব্যবহার না হলে ঘুমায় — লিংক খুললেই ৩০-৬০ সেকেন্ডে জেগে ওঠে |

## ⚠️ জেনে রাখুন

- **ফ্রি Space restart হলে** memory (আগের কথোপকথন) মুছে যেতে পারে —
  কারণ ফ্রি tier-এ স্থায়ী disk নেই। আপনার API key আর পাসওয়ার্ড ঠিক থাকবে (ওগুলো Secrets-এ)।
- Gemini ফ্রি tier-এ **দিনে সীমিত সংখ্যক প্রশ্ন** করা যায় (fallback মডেল মিলিয়ে দিনে ~৮০টা)।
- আপনার API key কাউকে দেবেন না, Access Code-ও না।
